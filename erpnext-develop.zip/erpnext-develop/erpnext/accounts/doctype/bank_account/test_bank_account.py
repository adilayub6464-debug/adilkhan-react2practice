# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt
import unittest

import frappe
from frappe import ValidationError
from frappe.tests import IntegrationTestCase


class TestBankAccount(IntegrationTestCase):
	pass
